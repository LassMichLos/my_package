# SPDX-FileCopyrightText: 2024-present LassMichLos <quang.nguyen@tu-dortmund.de>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
